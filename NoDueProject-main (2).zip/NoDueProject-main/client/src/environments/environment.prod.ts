export const environment = {
  build_version: 'v1.5',
  production: true,
  appurl: 'https://nodue-backend.onrender.com',
};
